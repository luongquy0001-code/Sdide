package com.example.sdide.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.sdide.engine.WorkspaceFileBridge
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.File

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sd_ide_prefs")

data class IdePreferences(
  val darkTheme: Boolean = true,
  val fontSizeSp: Int = 14,
  val showLineNumbers: Boolean = true,
)

data class WorkspaceState(
  val projectName: String,
  val entryFile: String,
  val files: LinkedHashMap<String, String>,
)

class ProjectRepository(private val context: Context) {

  companion object {
    private val KEY_DARK_THEME = booleanPreferencesKey("dark_theme")
    private val KEY_FONT_SIZE = intPreferencesKey("font_size_sp")
    private val KEY_LINE_NUMS = booleanPreferencesKey("show_line_numbers")
    private const val META_ENTRY_FILE = ".sdide_entry"
  }

  private val workspaceRoot: File
    get() = File(context.filesDir, "sd_workspace").apply { mkdirs() }

  private val currentProjectDir: File
    get() = File(workspaceRoot, "active_project").apply { mkdirs() }

  val preferencesFlow: Flow<IdePreferences> = context.dataStore.data.map { prefs ->
    IdePreferences(
      darkTheme = prefs[KEY_DARK_THEME] ?: true,
      fontSizeSp = (prefs[KEY_FONT_SIZE] ?: 14).coerceIn(11, 22),
      showLineNumbers = prefs[KEY_LINE_NUMS] ?: true,
    )
  }

  suspend fun setDarkTheme(isDark: Boolean) {
    context.dataStore.edit { it[KEY_DARK_THEME] = isDark }
  }

  suspend fun setFontSize(sizeSp: Int) {
    context.dataStore.edit { it[KEY_FONT_SIZE] = sizeSp.coerceIn(11, 22) }
  }

  fun loadOrSeedWorkspace(): WorkspaceState {
    val dir = currentProjectDir
    val codeFiles = listCodeFiles(dir)
    if (codeFiles.isEmpty()) {
      val starter = CurriculumExamples.samples.first()
      return saveSampleAsWorkspace(starter)
    }
    val entryMarker = File(dir, META_ENTRY_FILE)
    val storedEntry = if (entryMarker.exists()) entryMarker.readText().trim() else ""
    val map = LinkedHashMap<String, String>()
    for (f in codeFiles.sortedBy { it.name }) {
      map[f.name] = f.readText()
    }
    val entry = if (storedEntry in map) storedEntry else map.keys.first()
    return WorkspaceState(
      projectName = "Dự án Sd IDE",
      entryFile = entry,
      files = map,
    )
  }

  fun saveSampleAsWorkspace(sample: SampleProject): WorkspaceState {
    val dir = currentProjectDir
    dir.listFiles()?.forEach { it.deleteRecursively() }
    val filesMap = LinkedHashMap<String, String>()
    for ((name, content) in sample.files) {
      File(dir, name).writeText(content)
      filesMap[name] = content
    }
    File(dir, META_ENTRY_FILE).writeText(sample.entryFile)
    return WorkspaceState(
      projectName = sample.title,
      entryFile = sample.entryFile,
      files = filesMap,
    )
  }

  fun saveFile(fileName: String, content: String) {
    val safeName = sanitizeFileName(fileName)
    File(currentProjectDir, safeName).writeText(content)
  }

  fun setEntryFile(fileName: String) {
    File(currentProjectDir, META_ENTRY_FILE).writeText(sanitizeFileName(fileName))
  }

  fun deleteFile(fileName: String) {
    File(currentProjectDir, sanitizeFileName(fileName)).delete()
  }

  fun createFileBridge(): WorkspaceFileBridge {
    val dir = File(currentProjectDir, "data").apply { mkdirs() }
    return object : WorkspaceFileBridge {
      override fun writeFile(name: String, content: String) {
        val safe = name.substringAfterLast('/').substringAfterLast('\\')
        if (safe.isNotBlank()) {
          File(dir, safe).writeText(content)
        }
      }

      override fun readFile(name: String): String? {
        val safe = name.substringAfterLast('/').substringAfterLast('\\')
        val dataFile = File(dir, safe)
        if (dataFile.exists()) return dataFile.readText()
        val projFile = File(currentProjectDir, safe)
        if (projFile.exists()) return projFile.readText()
        return null
      }
    }
  }

  private fun listCodeFiles(dir: File): List<File> {
    return (dir.listFiles() ?: emptyArray()).filter {
      it.isFile && !it.name.startsWith(".") &&
        (it.name.endsWith(".sd") || it.name.endsWith(".sdpp") || it.name.endsWith(".sdall") || it.name.endsWith(".txt"))
    }
  }

  private fun sanitizeFileName(name: String): String {
    return name.trim().replace("/", "_").replace("\\", "_")
  }
}
